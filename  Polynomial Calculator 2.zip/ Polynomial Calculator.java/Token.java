
/**
 * A class to represent Tokens which includes monomials, parenthesis and +, -, /, * operators.
 *
 * @author Muhammad Furrukh Asif
 * @version CMPU-102
 */
public class Token
{
    /**
     * This character can be a parenthesis or one of the operators.
     */ 
    private char x;
    /**
     * This is a monomial
     */
    private Mono a;
    /**
     * This integer is the priority of the operator based on the order of operations.
     */
    private int priority;
    /**
     * A constructor for the Token class.
     */
    public Token(){
        this.x =x;
        this.priority = priority;
        this.a = a;
    }

    /**
     * This method is called on operators and it gives their priority.
     * @return  Integer-The priority of the operator.
     */
    public int getPriority(){
        return priority;
    }

     

     
}
