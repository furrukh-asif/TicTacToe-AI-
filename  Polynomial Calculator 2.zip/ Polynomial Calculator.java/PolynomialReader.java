
 
import java.util.ArrayList;
/**
 *  This class is a finite state machine that takes in a string representing a polynomial, breaks it down
 *  and returns an arraylist of objects
 * @author Muhammad Furrukh Asif
 * @version CMPU-102
 * 
 */
public class PolynomialReader
{
    /**
     * In a nested class, an enum is declared. This represents the state in which the FSM is currently. If a 
     * polynomial can end in a given state it is assigned true, if it cannot it is assigned false. For example,
     * a polynomial can end with an integer/double, therefore, the INT state is true. However, a polynomial
     * will be invald if it ends with a charat symbol, which is why the CH state is false.
     */
    public enum polState{
        INT(true),

        WDEC(false),

        DEC(true),

        X(true),

        ERR(false),

        CH(false),

        OPE(false),

        WRPAR(false),

        SIGN(false),

        RPAR(false),

        LPAR(true),

        EXP(true);

        private final boolean isAccept;
        /**
         * This constructor initialises the boolean(isAccept) of the states.
         */
        polState(boolean isAccept){
            this.isAccept = isAccept;
        }
        /**
         * This method returns the boolean(isAccept) of a state.
         */
        public boolean isAccept(){
            return isAccept;
        }
    }
    /**
     * This method turns a string representing a polynomial into an arraylist of Objects.
     * @param A string representing a polynomial.
     * @return An arraylist of objects.
     * <p>
     * This method moves from one state to other adding objects to an arraylist. These objects includes 
     * characters(+,-,*,/,(,) ) and monomials. A monomial is only added to the list after making sure that the
     * monomial has ended. If the user inputs something invalid, for eg. a charat symbol after an integer or a 
     * string ending in an operator, the FSM goes into the error state and returns an empty arraylist.
     */
    public static ArrayList readPolynomial(String input){
        polState curState = polState.WRPAR;
        String nwsInput = "";
        for(int j = 0; j < input.length();j++){
            char c1 = input.charAt(j);
            if(!Character.isWhitespace(c1)){
                nwsInput += c1;
            }
        }

        ArrayList listy = new ArrayList();

        String coef = "";
        String exp = "";
        int i = 0, inputlen = nwsInput.length();
        while(curState != polState.ERR && i < inputlen){
            char c =  nwsInput.charAt(i++);

            switch(curState){
                case WRPAR:
                if(c == '('){
                    listy.add(c);
                    curState = polState.RPAR;
                }
                else if(c == '+' || c == '-'){//check if we actually need the +
                    Mono b = new Mono(0,0);
                    listy.add(b);
                    listy.add(c);
                    curState = polState.SIGN;

                }
                else if(Character.isDigit(c)){

                    coef += c;
                    curState = polState.INT;
                    if(i == inputlen){
                        Mono b = new Mono(Double.parseDouble(coef), 0);
                        listy.add(    b);
                        coef = "";
                        exp = "";
                    }

                }
                else if(c =='.'){//depending on if we allow .1

                    coef += c;
                    curState = polState.WDEC;
                }
                else if(c == 'x'){

                    coef += 1;
                    curState = polState.X;
                    if(i == inputlen){
                        Mono b = new Mono(1, 1);
                        listy.add(    b);
                        coef = "";
                        exp = "";
                    }
                }
                else
                    curState = polState.ERR;
                break;

                case RPAR:
                if(c == '(')
                listy.add(c);
                else if(c == '+' || c == '-'){//not sure about the + sign.
                    Mono b = new Mono(0,0);
                    listy.add(   b);
                    listy.add( c);
                    curState = polState.SIGN;

                }
                else if(Character.isDigit(c)){

                    coef += c;
                    curState = polState.INT;
                    if(i == inputlen){
                        Mono b = new Mono(Double.parseDouble(coef), 0);
                        listy.add(  b);
                        coef = "";
                        exp = "";
                    }
                }
                else if (c == '.'){//depending on allowing .1

                    coef += c;
                    curState = polState.WDEC;
                }
                else if(c == 'x'){

                    coef += 1;
                    curState = polState.X;
                    if(i == inputlen){
                        Mono b = new Mono(1, 1);
                        listy.add(    b);
                        coef = "";
                        exp = "";
                    }
                }
                else
                    curState = polState.ERR;
                break;

                case SIGN:
                if(Character.isDigit(c)){

                    coef += c;

                    if(i == inputlen){
                        Mono b = new Mono(Double.parseDouble(coef), 0);
                        listy.add(    b);
                        coef = "";
                        exp = "";
                    }
                    curState = polState.INT;
                }
                else if(c == '('){
                    listy.add( c);
                    curState = polState.RPAR;
                }
                else if(c =='.'){ //depending if we allow .1

                    coef += c;
                    curState = polState.WDEC;
                }
                else if(c == 'x'){

                    coef += 1;
                    curState = polState.X;
                    if(i == inputlen){
                        Mono b = new Mono(1, 1);
                        listy.add(   b);
                        coef = "";
                        exp = "";
                    }
                }
                else
                    curState = polState.ERR;
                break;

                case INT:
                if(Character.isDigit(c)){

                    coef += c;
                    if(i == inputlen){
                        Mono b = new Mono(Double.parseDouble(coef), 0);
                        listy.add(b);
                        coef = "";
                        exp = "";
                    }

                }
                else if(c == '.'){
                    coef += c;
                    curState = polState.WDEC;
                }
                else if(c == 'x'){

                    curState = polState.X;
                    if(i == inputlen){
                        Mono b = new Mono(Double.parseDouble(coef), 1);
                        listy.add(b);
                        coef = "";
                    }
                }
                else if(c == '+' || c == '-'){
                    Mono b = new Mono(Double.parseDouble(coef), 0);
                    listy.add(    b);
                    coef = "";
                    exp = "";
                    listy.add(  c);
                    curState = polState.SIGN;

                }
                else if(c == '*' || c == '/'){
                    Mono b = new Mono(Double.parseDouble(coef), 0);
                    listy.add(    b);
                    coef = "";
                    exp = "";
                    listy.add(  (Object) c);
                    curState = polState.OPE;

                }
                else if(c == ')'){
                    Mono b = new Mono(Double.parseDouble(coef), 0);
                    listy.add(   b);
                    coef = "";
                    exp = "";
                    listy.add(  (Object) c);
                    curState = polState.LPAR;
                }
                else
                    curState = polState.ERR;
                break;

                case WDEC:
                if(Character.isDigit(c)){

                    coef += c;
                    curState = polState.DEC;
                    if(i == inputlen){
                        Mono b = new Mono(Double.parseDouble(coef), 0);
                        listy.add( b);
                        coef = "";
                        exp = "";
                    }
                }

                else
                    curState = polState.ERR;
                break;

                case DEC:
                if(Character.isDigit(c)){

                    coef += c;
                    if(i == inputlen){
                        Mono b = new Mono(Double.parseDouble(coef), 0);
                        listy.add(  b);
                        coef = "";
                        exp = "";
                    }
                }
                else if(c == 'x'){
                    
                    curState = polState.X;
                    if(i == inputlen){
                        Mono b = new Mono(Double.parseDouble(coef), 1);
                        listy.add(  b);
                        coef = "";
                        exp = "";
                    }
                }
                else if(c == '+' || c == '-'){
                    Mono b = new Mono(Double.parseDouble(coef), 0);
                    listy.add(  b);
                    coef = "";
                    exp = "";
                    listy.add(  c);
                    curState = polState.SIGN;

                }
                else if(c == '*' || c == '/'){
                    Mono b = new Mono(Double.parseDouble(coef), 0);
                    listy.add(  b);
                    coef = "";
                    exp = "";
                    listy.add(   c);
                    curState = polState.OPE;

                }
                else if(c == ')'){
                    Mono b = new Mono(Double.parseDouble(coef), 0);
                    listy.add(   b);
                    coef = "";
                    exp = "";
                    listy.add(  c);
                    curState = polState.LPAR;
                }
                else
                    curState = polState.ERR;
                break;

                case X:
                if(c == '^'){

                    curState = polState.CH;
                }
                else if(c == '+' || c == '-'){

                    Mono b = new Mono(Double.parseDouble(coef), 1);
                    listy.add(   b);
                    coef = "";
                    exp = "";

                    listy.add(  c);
                    curState = polState.SIGN;

                }
                else if(c == '*' || c == '/'){

                    Mono b = new Mono(Double.parseDouble(coef), 1);
                    listy.add(  b);
                    coef = "";
                    exp = "";

                    listy.add(   c);
                    curState = polState.OPE;

                }
                else if(c == ')'){

                    Mono b = new Mono(Double.parseDouble(coef), 1);
                    listy.add(  b);
                    coef = "";
                    exp = "";

                    listy.add(c);
                    curState = polState.LPAR;
                }
                else
                    curState = polState.ERR;
                break;

                case CH:
                if(Character.isDigit(c) && i == inputlen){

                    exp += c;
                    Mono b = new Mono(Double.parseDouble(coef),Integer.parseInt(exp));
                    listy.add(   b);
                    coef = "";
                    exp = "";
                    curState = polState.INT;
                }
                else if(Character.isDigit(c)){
                    exp += c;
                    curState = polState.EXP;
                }
                else
                    curState = polState.ERR;
                break;

                case EXP:
                if(Character.isDigit(c)){
                    exp += c;
                    if(i == inputlen){
                        Mono b = new Mono(Double.parseDouble(coef),Integer.parseInt(exp));
                        listy.add(b);
                        coef = "";
                        exp = "";
                    }
                }
                else if(c == '+' || c == '-'){

                    Mono b = new Mono(Double.parseDouble(coef),Integer.parseInt(exp));
                    listy.add(b);
                    listy.add(c);
                    coef = "";
                    exp = "";
                    curState = polState.SIGN;

                }
                else if(c == '*' || c == '/'){
                    Mono b = new Mono(Double.parseDouble(coef),Integer.parseInt(exp));
                    listy.add(b);
                    listy.add(c);
                    coef = "";
                    exp = "";
                    curState = polState.OPE;

                }
                else if(c == ')'){
                    Mono b = new Mono(Double.parseDouble(coef),Integer.parseInt(exp));
                    listy.add(b);
                    listy.add(c);
                    coef = "";
                    exp = "";
                    curState = polState.LPAR;
                }
                else
                    curState = polState.ERR;
                break;

                case LPAR:
                if(c == '*' || c == '/'){
                    listy.add(c);
                    curState = polState.OPE;


                }
                else if(c == '+' || c == '-'){
                    listy.add(  c);
                    curState = polState.SIGN;

                }
                else if(c == ')')
                listy.add(c);
                else
                    curState = polState.ERR;
                break;

                case OPE:
                if(c == '('){
                    listy.add( c);
                    curState = polState.RPAR;
                }
                else if(Character.isDigit(c)){


                    coef += c;

                    if(i == inputlen){
                        Mono b = new Mono(Double.parseDouble(coef), 0);
                        listy.add(b);
                        coef = "";
                        exp = "";
                    }

                    curState = polState.INT;
                }
                else if(c == 'x'){
                    coef += 1;
                    curState = polState.X;
                    if(i == inputlen){
                        Mono b = new Mono( 1, 1);
                        listy.add(b);
                        coef = "";
                        exp = "";
                    }
                }
                else if(c == '.'){
                    coef += c;
                    curState = polState.WDEC;
                }
                else
                    curState = polState.ERR;
                break;

            }
              
        }
        ArrayList b = new ArrayList();

         

        if(curState.isAccept())
            b = listy;
        
        return b;
    }
}
