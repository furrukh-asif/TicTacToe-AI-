





import java.util.*;
import java.text.DecimalFormat;
/**
 * 
 * Represents a monomial, i.e a single term polynomial.
 * @author Muhammad Furrukh Asif
 * @version CMPU-102 with Rui Merieles
 */
public class Mono implements Comparable
{
    /**
     *  Represents the coefficient of the monomial. 
     */
    public double coeff;
    /**
     * Represents the exponent of the monomial.
     */
    public int expo;
     
    /**
     * Constructor for objects of class Monomial.
     */
    public Mono(double coeff,int expo)
    {
        this.coeff = coeff;
        this.expo = expo;
    }
    /**
     * Implements the compareTo method to arrange monomials in descending order of exponents.
     * @param Object
     * @return Integer
     */
    public int compareTo(Object o){
        Mono a1 = (Mono) o;
        if(this.expo < a1.expo){
            return -1;
        }
        else if(this.expo > a1.expo){
            return 1;
        }
        else{
            return 0;
        }
    }
    /**
     *  Implements the toString method for the monomial class.
     * @return String - string representation of a monomial.
     * <p>
     * The method rounds the coefficient to 3 significant figures.
     */
    public String toString()
    {
        String s = "";
        DecimalFormat  dec = new DecimalFormat("#.000");
         
        if(expo == 1 && coeff == 1)
        s += "x";
        else if(expo == 0 && coeff < 0)
        s += " - " +  Math.round(-1*coeff*Math.pow(10, 3))/Math.pow(10, 3);
        else if (expo == 0)
        s +=  coeff;
        else if(expo == 1 && coeff < 0)
        s += " - " +  Math.round(-1*coeff*Math.pow(10, 3))/Math.pow(10, 3) + "x";
        else if(expo == 1)
        s +=  Math.round(coeff*Math.pow(10, 3))/Math.pow(10, 3) + "x";
        else if(coeff == 1)
        s += "x^" + expo;
        else{
              s += Math.round(coeff*Math.pow(10, 3))/Math.pow(10, 3) + "x^" 
              + expo;
        }
        return s;
    }
}
