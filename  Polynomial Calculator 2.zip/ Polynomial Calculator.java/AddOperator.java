
/**
 * A subclass of the Operator class, representing the add operator.
 *
 * @author Muhammad Furrukh Asif
 * @version CMPU-102
 */
public class AddOperator extends Operator
{
     
    private char a;
    private int priority;
    /**
     *  A constructor for the AddOperator class.
     *  <p>
     *  The character is initialised to be '+' and a priority of 0 is assigned.
     */
    public AddOperator()
    {
        priority = 0; 
        a = '+';
    }

    /**
     *  This method gives the priority of the add operator.
     * @return    Integer - the priority of the operator
     */
    public int getPriority()
    {
         
        return priority;
    }
    /**
     * Implements the toString method for the AddOperator class.
     * @return String - a string representation of the operator.
     */
     
    public String toString(){
        String s;
        s = "" + '+';
        return s;
    }
}
