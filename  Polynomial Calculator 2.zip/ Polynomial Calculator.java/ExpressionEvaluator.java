import java.util.*;
/**
 * This class evaluates the postfix expression to give a result.
 *
 * @author Muhammad Furrukh Asif
 * @version CMPU-102
 */
public class ExpressionEvaluator
{
    /**
     * This method takes the arraylist of the polynomial expressionn which is in
     * postfix notation and evaluates it, to give a resultant polynomial.
     * @param ArrayList  list of objects representing the polynomial expreesion in 
     * postfix notation
     * @return Poly - the result of the polynomial expression
     * <p>
     * This method uses a for loop to iterate through the arraylist of objects. It 
     * casts every object in the list which is not a monomial to the Token class. If 
     * the object is a monomial, it creates a polynomial out of it and adds it to the 
     * arraydeque. If it is an operator, it removes the last two polynomials entered
     * in the deque, applies the method relevant to the operator(for e.g '+'=>addition)
     * and adds the result back to the deque if it is not null. Once the for loop ends,
     * the deque contains one polynomial which is the final result. The method retrives
     * this polynomial and returns it.
     */
    public Poly evaluator(ArrayList postfix){
        ArrayDeque<Poly> stack  = new ArrayDeque<Poly>();

        for(int i = 0; i < postfix.size(); i++){
            Object a = postfix.get(i);
            Token y = new Token();
            Poly t = new Poly();
            Poly z = new Poly();
            if(a instanceof Mono == false)
                y = (Token) (Object) a;
            if(a instanceof Mono){
                Mono c = (Mono) a;

                Poly b = new Poly();
                b.tree.put(c.expo, c);

                stack.push(b);

            }
            else  {
                t = stack.pop();
                z = stack.pop();

                Poly result = new Poly();

                if(y instanceof AddOperator)
                    result = z.add(t);
                else if(y instanceof SubOperator)
                    result = z.subtract(t);
                else if(y instanceof MulOperator){

                    result = z.multiply(t);
                }
                else if(y instanceof DivOperator)
                    result = z.divide(t);

                if(result != null)
                    stack.push(result);
            }

        }
        Poly finalresult = new Poly();
        try{
            finalresult = stack.pop();
        }
        catch(NoSuchElementException e){
        }
        return finalresult;
    }
}
