
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;
import java.io.*;
import javax.swing.filechooser.*;
import java.awt.image.ColorConvertOp;
import java.awt.color.ColorSpace;
import java.awt.SystemColor;
/**
 * A graphical user interface polynomial calculator.
 * @author Muhammad Furrukh Asif
 * @version CMPU-102
 */
public class MainGUI
{
    private static final String interactiveS = "1";
    private static final String fileS = "2";
    private static final String exitS = "EXIT"; 
    private static final String changeS = "0"; 
    /**
     *A HashMap to store the saved polynomials.
     */
    HashMap<Character ,Poly> results = new HashMap<Character,Poly>();
    /**
     * A FSM to break the expression into an arraylist fo objects.
     */
    PolynomialReader fsm = new PolynomialReader();
    /**
     * A converter to convert the arraylist into postfix notation.
     */
    InfixtoPostfix convert = new InfixtoPostfix();
    /**
     * This evaluates the expression and gives the result.
     */
    ExpressionEvaluator evaluation = new ExpressionEvaluator();
    /**
     * The window representing the menu.
     */
    JFrame window;
    /**
     * The window representing the interactive mode.
     */
    JFrame window2;
    /**
     * The window representing the file mode.
     */
    JFrame window3;
    /**
     * The text field in the interactive mode where the user types in a polynomial expression.
     */
    JTextField polyexpr;
    /**
     * A label where the result of the expression is printed.
     */
    JLabel resLab;
    /**
     * A button which when pressed evaluates the expression.
     */
    JButton evaluate;
    /**
     * A button in interactive mode to return to the menu.
     */
    JButton rmenu;
    /**
     * A button in file mode to return to the menu.
     */
    JButton rmenu1;
    /**
     * A button in the file mode to open a text file.
     */
    JButton ofile;
    /**
     * The text area in the file mode where the results are displayed.
     */
    JTextArea farea; 
    /**
     * A button to turn on dark mode for the GUI.
     */
    JButton darkmode;
    /**
     * A button on the menu to implement the interactive mode.
     */
    JButton interactive;
    /**
     * A button on the menu to implement the file mode.
     */
    JButton file;
    /**
     * A button on the menu to exit the program.
     */
    JButton exit;
    /**
     * A label with a welcome statement, asking the user to choose a mode.
     */
    JLabel label;
    /**
     * A label in the interactive mode, asking the user for an expression.
     */
    JLabel label2;
    /**
     *A label in the file mode, asking the user to open a text file.
     */
    JLabel label3;
    /**
     * A constructor for the MainGUI class.
     * <p>
     * In this constructor, the GUI is implemented. It has three windows, the main 
     * menu, interactive mode and filemode. 
     * The menu has three buttons to choose one of the modes or to exit. 
     * 
     * The interactive mode has a text field where the user would input the polynomial
     * expression. There is a button to evaluate the expression and another one to 
     * return to main menu. After being evaluated the result is printed on the window.
     * 
     * The file mode window has a button to open a file and another one to return to
     * main menu. It also has text area where the polynomial results are printed.
     */
    MainGUI(){
        window = new JFrame("Polynomial Calculator");
        window.setSize(600,350);
        window.setLocationRelativeTo(null);

        JPanel content = new JPanel();
        window.getContentPane().setLayout(null);
        label = new JLabel
        ("<html>Welcome to Polynomial Calculator by Furrukh Asif<br>Choose a mode:");
        content.add(label);

        ActionListener al = new ButtonHandler();
        interactive = new JButton("Interactive"); 
        interactive.setActionCommand(interactiveS);
        interactive.addActionListener(al);

        content.add(interactive);
        file = new JButton("File");
        file.setActionCommand(fileS);
        file.addActionListener(al);

        content.add(file);
        exit = new JButton("Exit");
        exit.setActionCommand(exitS);
        exit.addActionListener(al);
        content.add(exit);

        darkmode = new JButton("Dark Mode");
        darkmode.setActionCommand(changeS);
        darkmode.addActionListener(al);
        content.add(darkmode);

        window.setContentPane(content);

        window.setVisible(true);

        window2 = new JFrame("Polynomial Calculator");
        window2.setSize(600,350);
        window2.setLocationRelativeTo(null);

        JPanel content2 = new JPanel();

        label2 = new JLabel("<html>Interactive Mode<br>Enter a polynomial here:");
        content2.add(label2);

        polyexpr = new JTextField(20);
        content2.add(polyexpr);

        evaluate = new JButton("Evaluate");
        content2.add(evaluate);

        resLab = new JLabel("");
        content2.add(resLab);

        rmenu = new JButton("Return to menu");
        content2.add(rmenu);

        window2.setContentPane(content2);
        window2.setVisible(false); 

        window3 = new JFrame();
        window3.setSize(600,350);
        window3.setLocationRelativeTo(null);

        JPanel content3 = new JPanel();

        label3 = new JLabel("<html>File Mode<br>Open a txt file.");
        content3.add(label3);

        farea = new JTextArea(10,15);
        content3.add(farea);

        ofile = new JButton("Open File");
        content3.add(ofile);

        rmenu1 = new JButton("Return to menu");
        content3.add(rmenu1);

        window3.setContentPane(content3);
        window3.setVisible(false);
    }

    //This is where the computer is told what to do when a button is pressed. For example, if the user presses the interactive mode
    //button in the menu window, we set the string, 'mode' to be one, which results in the menu window disappering and the intercative
    //mode window being visible. Similarly, pressing the file mode button makes the file mode window visible and teh exit button, simply 
    //exits the program. 
    //In the interactive mode window, the user provides input in the text field. When the evaluate button is pressed, the input is read and 
    //evaluated similar to what is done in the text-based calculator. However, instead of error being printed out, in this GUI errors
    //are displayed as message dialogs specifying what the error is. If no errors the result of the expression is displayed on the window.
    //In the file mode, there is a open file button, which when pressed allows the user to select a file saved in the computer. However, it
    //only allows the user to select a text file. Once the file is open, it is read and the expressions in it evaluated similar to the 
    //text-based calculator. Error messages are shown similiar to the interactive mode and the results displayed on the window.
    //Both the modes, have a return to menu button, if the user wants to change modes or quit the program.

    private class ButtonHandler implements ActionListener{
        public void actionPerformed(ActionEvent f){

            final String st = f.getActionCommand();
            String mode = "";

            switch(st){
                case interactiveS:
                mode = "1";
                break;
                case fileS:
                mode = "2";
                break;
                case exitS:
                mode = "EXIT";
                case changeS:
                if (darkmode.getText() == "Dark Mode"){
                darkmode.setText("Light Mode");
                label.setForeground(Color.white);
                change(interactive);
                change(exit); 
                change(file);
                change(darkmode);
                label2.setForeground(Color.white);
                change(evaluate);
                change(rmenu);
                resLab.setForeground(Color.white);
                label3.setForeground(Color.white);
                change(ofile);
                change(rmenu1);
                window.getContentPane().setBackground(Color.DARK_GRAY);
                window2.getContentPane().setBackground(Color.DARK_GRAY);
                window3.getContentPane().setBackground(Color.DARK_GRAY);
            }
            else{
                darkmode.setText("Dark Mode");
                label.setForeground(Color.black);
                change1(interactive);
                change1(exit); 
                change1(file);
                change1(darkmode);
                label2.setForeground(Color.black);
                change1(evaluate);
                change1(rmenu);
                resLab.setForeground(Color.black);
                label3.setForeground(Color.black);
                change1(ofile);
                change1(rmenu1);
                window.getContentPane().setBackground(SystemColor.window);
                window2.getContentPane().setBackground(SystemColor.window);
                window3.getContentPane().setBackground(SystemColor.window);
            }
            break;
            }

            if(mode.equals("1")){
                window.setVisible(false);
                window2.setVisible(true);

                rmenu.addActionListener(new ActionListener(){
                        public void actionPerformed(ActionEvent y){
                            window2.setVisible(false);
                            window.setVisible(true);

                        }
                    });
                evaluate.addActionListener(new ActionListener()
                    {
                        public void actionPerformed(ActionEvent z) {

                            String nwsInput = polyexpr.getText().replaceAll("\\s","");    
                            String[] inputContents = nwsInput.split("=");
                            String resultName = "";
                            String inputExpr = "";
                            Poly result = new Poly();

                            if(inputContents.length == 2){  
                                resultName = inputContents[0];
                                if(resultName.length() != 1)
                                    JOptionPane.showMessageDialog(null,"Expression: " + polyexpr.getText() + "\n\nAssign a single character name.","error",JOptionPane.ERROR_MESSAGE);

                                inputExpr = inputContents[1];
                            }
                            else if(inputContents.length == 1)
                                inputExpr = inputContents[0];
                            else
                                JOptionPane.showMessageDialog(null,"Expression: " + polyexpr.getText() + "\n\nInvalid expression","error",JOptionPane.ERROR_MESSAGE);

                            String newInputExpr = "";
                            for(int i = 0; i < inputExpr.length(); i++){
                                char c = inputExpr.charAt(i);
                                if(results.containsKey(c))
                                    newInputExpr += "(" + results.get(c) + ")";
                                else
                                    newInputExpr += c;
                            }

                            ArrayList a = fsm.readPolynomial(newInputExpr);

                            if(a.isEmpty())
                                JOptionPane.showMessageDialog(null,"Expression: " + polyexpr.getText() + "\n\nInvalid Input","error",JOptionPane.ERROR_MESSAGE);
                            ArrayList b = new ArrayList();

                            try{
                                b = convert.converter(a);
                            }
                            catch(IllegalArgumentException e){
                                JOptionPane.showMessageDialog(null,"Expression: " + polyexpr.getText() + "\n\n" + e.getMessage(), "error",JOptionPane.ERROR_MESSAGE);
                                return;
                            }

                            try{
                                result = evaluation.evaluator(b);
                            }
                            catch(ArithmeticException e){
                                JOptionPane.showMessageDialog(null, "Expression: " + polyexpr.getText() + "\n\n" + e.getMessage(), "error",JOptionPane.ERROR_MESSAGE);
                                return;
                            }

                            if(inputContents.length == 2)
                                results.put(resultName.charAt(0), result);
                            resLab.setText("Expression: " + polyexpr.getText() 
                            + "\n Result: " + result.toString());
                             
                        }
                    });

            }

            else if(mode.equals("2")){
                window.setVisible(false);
                window3.setVisible(true); 
                rmenu1.addActionListener(new ActionListener(){
                        public void actionPerformed(ActionEvent y){
                            window3.setVisible(false);
                            window.setVisible(true);

                        }
                    });

                ofile.addActionListener(new ActionListener(){
                        public void actionPerformed (ActionEvent t){
                            JFileChooser fc = new JFileChooser();
                            FileNameExtensionFilter filter 
                            = new FileNameExtensionFilter("Text Files", "txt");    
                            fc.setFileFilter(filter);
                            Poly result = new Poly();
                            int returnVal = fc.showOpenDialog(window3); 

                            if(returnVal == JFileChooser.APPROVE_OPTION){
                                StringBuilder sb = new StringBuilder();

                                File file = fc.getSelectedFile();
                                try{
                                    BufferedReader r = 
                                        new BufferedReader(new FileReader(file));
                                    String line;
                                    while((line = r.readLine()) != null){

                                        String nwsInput = line.replaceAll("\\s","");
                                        String[] inputContents = nwsInput.split("=");
                                        String resultName = "";
                                        String inputExpr = "";
                                        if(inputContents.length == 2){  
                                            resultName = inputContents[0];
                                            if(resultName.length() != 1){
                                                JOptionPane.showMessageDialog
                                                (null,"Expression: " + line + "\n\nAssign a single character name.",
                                                    "error",JOptionPane.ERROR_MESSAGE);
                                                    continue;
                                            }
                                            inputExpr = inputContents[1];

                                        }
                                        else if(inputContents.length == 1)
                                            inputExpr = inputContents[0];
                                        else{
                                            JOptionPane.showMessageDialog(null,
                                                "Expression: " + line + "\n\nInvalid expression","error",
                                                JOptionPane.ERROR_MESSAGE);
                                            continue;
                                        }
                                        String newInputExpr = "";
                                        for(int i = 0; i < inputExpr.length(); i++){
                                            char c = inputExpr.charAt(i);
                                            if(results.containsKey(c))
                                                newInputExpr += "(" +
                                                results.get(c) + ")";
                                            else
                                                newInputExpr += c;
                                        }

                                        ArrayList a = fsm.readPolynomial(newInputExpr);

                                        if(a.isEmpty()){
                                            JOptionPane.showMessageDialog(null, 
                                                 "Expression: " + line + "\n\nInvalid expression","error",
                                                JOptionPane.ERROR_MESSAGE);
                                                continue;
                                            }
                                        ArrayList b = new ArrayList();
                                        try{
                                            b = convert.converter(a);
                                        }
                                        catch(IllegalArgumentException e){
                                            JOptionPane.showMessageDialog(null,
                                               "Expression: " + line + "\n\n" + e.getMessage(), "error",
                                                JOptionPane.ERROR_MESSAGE);
                                            continue;
                                        }

                                        try{
                                            result = evaluation.evaluator(b);
                                        }
                                        catch(ArithmeticException e){
                                            JOptionPane.showMessageDialog(null,
                                                "Expression: " + line + "\n\n" + e.getMessage(), "error",
                                                JOptionPane.ERROR_MESSAGE);
                                            continue;
                                        }

                                        if( inputContents.length == 2){
                                            results.put(resultName.charAt(0), result);
                                        }
                                        sb.append("Expression: " + line + "\n");
                                        sb.append("Result: " + result.toString());
                                        sb.append("\n");
                                    }

                                    farea.setText(sb.toString());
                                    r.close();
                                }
                                catch (IOException e) { 
                                    System.err.println(e); 
                                }
                            }

                        }

                    });
                window3.toFront();
            }

            else if(mode.equals("EXIT")){
                System.exit(0);

            }
        }

    }

    /**
     * A method running a graphical user interface of a polynomial calculator.
     */
    public static void main(){
        new MainGUI();
    }
    /**
     * This method acts on a button, to change its appearance.
     */
    public void change(JButton a){
        a.setForeground(Color.white);
        a.setBackground(Color.LIGHT_GRAY);
        a.setOpaque(false);
        a.setBorderPainted(false);
    }
    /**
     * This method acts on a button, to change its appearance.
     */
    public void change1(JButton a){
        a.setForeground(Color.black);
        a.setBackground(SystemColor.inactiveCaptionBorder);
        a.setOpaque(false);
        a.setBorderPainted(true);
    }
}
