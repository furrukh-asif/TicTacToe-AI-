
/**
 * A subclass of the Token class, representing right & left parenthesis
 *
 * @author Muhammad Furrukh Asif
 * @version CMPU-102
 */
public class Paren extends Token
{
    
    private char a;

    /**
     * A constructor for the class Paren.
     */
    public Paren()
    {
        this.a = a;
    }

}
