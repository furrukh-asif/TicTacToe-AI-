
 /**
 * A subclass of the Operator class, representing the multiply operator.
 *
 * @author Muhammad Furrukh Asif
 * @version CMPU-102
 */
public class MulOperator extends Operator
{
     
    private char a;
    private int priority;
    /**
     *  A constructor for the MulOperator class.
     *  <p>
     *  The character is initialised to be '*' and a priority of 2 is assigned.
     */
    public MulOperator()
    {
        a = '*';
        priority = 2;
    }

    /**
     *  This method gives the priority of the multiply operator.
     * @return    Integer - the priority of the operator
     */
    public int getPriority()
    {
         
        return priority;
    }
    /**
     * Implements the toString method for the MulOperator class.
     * @return String - a string representation of the operator.
     */
     
    public String toString(){
        String s;
        s = "" + '*';
        return s;
    }
}
