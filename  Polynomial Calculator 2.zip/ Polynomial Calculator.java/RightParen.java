
/**
 * A subclass of the class Paren, representing the right parenthesis.
 *
 * @author Muhammad Furrukh Asif
 * @version CMPU-102
 */
public class RightParen extends Paren
{
     
    private char a;

    /**
     * A constructor for the RightParen class, where the character is initailised as ')'.
     */
    public RightParen()
    {
        a = ')';
        
    }

     /**
     * Implementation of the toString method for the RightParen class.
     *
     * @return String - String representation of a left parenthesis
     */
     
    
    public String toString(){
        String s;
        s = "" + ')';
        return s;
    }
}
