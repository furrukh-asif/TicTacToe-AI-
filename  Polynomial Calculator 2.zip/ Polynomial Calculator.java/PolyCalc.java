
 
import java.util.*;
import java.util.Arrays;
import java.io.*;
/**
 * Implements a text-based polynomial calculator
 * @author Muhammad Furrukh Asif
 * @version CMPU-102
 */
public class PolyCalc
{
    /**
     * Runs a text-based polynomial calculator repeatedly, until the user quits.
     * <p>
     * The user is first asked to select a mode. 
     *
     * In the interactive mode the user inputs the polynomial expressions using the 
     * keyboard. Inorder to allow for polynomials to be saved the user would input
     * an expression like, 'a = x + 1'.This will save the result of the expression in 
     * a HashMap where the key will be 'a' and the value the result. This is done by 
     * first splitting the input expression at '=', saving the first index as the key 
     * and evaluating the second index of the array of strings as a polynomial 
     * expression. If the string splits into more than two strings its an invalid 
     * input. Saved polynomials can be used again inexpressions for which there is a 
     * for loop to check if any character in the input expression is a key in 
     * the HashMap. If it is the character is replaced by the saved polynomial. 
     * This method checks for any invalid expressions by making sure the FSM doesn't 
     * throw out an empty list and by catching the exceptions thrown by converter 
     * and evaluator methods. It then prints out the expression and result on the 
     * screen. The user can exit the mode by typing 'exit', which is not case-sensitive.
     * 
     * In the file mode, the basic organization is the same. Instead of typing in
     * polynomials as input, the user provides the address of a textfile. The method
     * then reads all the polynomials in the file using a buffered reader and 
     * evaluates them. 
     * 
     * The user can enter 'exit' when in the menu to quit where 'exit' is not
     * case-sensitive.
     */ 
    public static void main(String args []){
        HashMap<Character ,Poly> results = new HashMap<Character,Poly>();
            PolynomialReader fsm = new PolynomialReader();
            InfixtoPostfix convert = new InfixtoPostfix();
            ExpressionEvaluator evaluation = new ExpressionEvaluator();
        while(true){

            System.out.println("Select one of the following modes");
            System.out.println("For interactive mode press 1");
            System.out.println("For file mode press 2");
            System.out.println("To exit, enter 'exit'");
            Scanner scanner = new Scanner(System.in);
            String mode = scanner.nextLine();
             

            if(mode.equals("1")){

                while(true){

                    System.out.println("Please enter a valid expression.(Enter 'exit' to return to menu)");
                    Scanner scanner1 = new Scanner(System.in);
                    String input = scanner1.nextLine();
                    String nwsInput = input.replaceAll("\\s","");

                    String[] inputContents = nwsInput.split("=");

                    String resultName = "";
                    String inputExpr = "";

                    if(nwsInput.toLowerCase().equals("exit"))
                        break;

                    if(inputContents.length == 2){  
                        resultName = inputContents[0];
                        if(resultName.length() != 1){
                            System.out.println("Please assign a single character name");
                            break;
                        }
                        inputExpr = inputContents[1];

                    }
                    else if(inputContents.length == 1)
                        inputExpr = inputContents[0];
                    else{
                        System.out.println("Invalid Input");
                        break;
                    }
                    String newInputExpr = "";
                    for(int i = 0; i < inputExpr.length(); i++){
                        char c = inputExpr.charAt(i);
                        if(results.containsKey(c))
                            newInputExpr += "(" + results.get(c) + ")";
                        else
                            newInputExpr += c;
                    }

                    ArrayList a = fsm.readPolynomial(newInputExpr);
                    if(a.isEmpty()){
                        System.out.println("Expression: " + input);
                        System.out.println("Invalid Expression");
                        continue;
                    }

                    ArrayList b = new ArrayList(); 
                    try{
                        b = convert.converter(a);
                    }
                    catch(IllegalArgumentException e){
                        System.out.println("Expression: " + input);
                        System.out.println(e.getMessage()); 
                        continue;
                    }

                    Poly result = new Poly();
                    try{
                        result = evaluation.evaluator(b);
                    }
                    catch(ArithmeticException e){
                        System.out.println("Expression: " + input);
                        System.out.println(e.getMessage()); 
                        continue;
                    }

                    if(inputContents.length == 2){
                        results.put(resultName.charAt(0), result);

                    }
                    System.out.println("Expression: " + input);
                    System.out.println("Result: " + result);
                    System.out.println("All results: " + results);
                }
            }

            else if(mode.equals("2")){
                while(true){
                    System.out.println("Enter a filename.(Enter 'exit' to return to menu)");
                    Scanner scanner3 = new  Scanner(System.in);
                    String filename = scanner3.nextLine();
                    File file = new File(filename);
                    if(filename.toUpperCase().equals("EXIT"))
                        break;
                    try{
                        if(file.exists()){
                            if(file.isFile()){
                                try{
                                    BufferedReader r = 
                                        new BufferedReader(new FileReader(filename));
                                    String line ;
                                    while((line = r.readLine()) != null){
                                        String nwsInput = line.replaceAll("\\s","");

                                        String[] inputContents = nwsInput.split("=");

                                        String resultName = "";
                                        String inputExpr = "";
                                        if(inputContents.length == 2){  
                                            resultName = inputContents[0];
                                            if(resultName.length() != 1){
                                                System.out.println("Expression: " + line);
                                                System.out.println("Please assign a single character name");
                                                break;
                                            }
                                            inputExpr = inputContents[1];

                                        }
                                        else if(inputContents.length == 1)
                                            inputExpr = inputContents[0];
                                        else{
                                            System.out.println("Expression: " + line);
                                            System.out.println("Invalid Input");
                                            continue;
                                        }
                                        String newInputExpr = "";
                                        for(int i = 0; i < inputExpr.length(); i++){
                                            char c = inputExpr.charAt(i);
                                            if(results.containsKey(c))
                                                newInputExpr += "(" + results.get(c) + ")";
                                            else
                                                newInputExpr += c;
                                        }
                                        ArrayList a = fsm.readPolynomial(newInputExpr);
                                        if(a.isEmpty()){
                                            System.out.println("Expression: " + line);
                                            System.out.println("Invalid Expression");
                                            continue;
                                        }

                                        ArrayList b = new ArrayList(); 
                                        try{
                                            b = convert.converter(a);
                                        }
                                        catch(IllegalArgumentException e){
                                            System.out.println("Expression: " + line);
                                            System.out.println(e.getMessage()); 
                                            continue;
                                        }

                                        Poly result = new Poly();
                                        try{
                                            result = evaluation.evaluator(b);
                                        }
                                        catch(ArithmeticException e){
                                            System.out.println("Expression: " + line);
                                            System.out.println(e.getMessage()); 
                                            continue;
                                        }

                                        if( inputContents.length == 2){
                                            results.put(resultName.charAt(0), result);
                                        }
                                        System.out.println("Expression: " + line);
                                        System.out.println("Result: " + result);
                                    }
                                    r.close();
                                }
                                catch (IOException e) { 
                                    System.err.println(e); 
                                }
                            }
                            else 
                                System.out.println("This is not a file");
                        }
                        else
                            System.out.println("This file does not exist");
                    }
                    catch(SecurityException e) { 
                        System.err.println(e);
                    }
                }
            }
            else if(mode.toUpperCase().equals("EXIT"))
                break;
            else
                System.out.println("Invalid Input");
        }
    }
}

