
import java.lang.*;
import java.util.*;
import java.util.List;
import java.util.ArrayList;
import java.lang.Iterable;
import java.util.TreeMap;
/**
 * A class for polynomials with methods for addition, subtraction, multiplication & division.
 *
 * @author Muhammad Furrukh Asif
 * @version CMPU-102
 */

public class Poly  
{
    /**
     * A tree map that represents a polynomial, where the key is the exponent and the value is a monomial.
     */
    SortedMap<Integer,Mono> tree;
    /**
     * A constructor for the polynomial class.
     */
    public Poly(){
        tree = new TreeMap<Integer,Mono>(Collections.reverseOrder());
    }

    /**
     * A method to remove monomials in a polynomial that have a zero coefficient.
     * @param Polynomial which is to be checked for zero coefficient monomials.
     * @return Polynomial-without monomials with zero coeeficients.
     * <p>
     * This method uses an iterator and while loop to iterate through the polynomial(tree map) and checks
     * if a monomial has a zero coefficient. If it does it removes the monomial. The remaing polynomial
     * is returned.
     */
    public Poly checkForZero(Poly b){
        Set<Integer> set = b.tree.keySet();
        Iterator<Integer> itr = set.iterator();
        ArrayList<Integer> co0 = new ArrayList<Integer>();
        while(itr.hasNext()){
            int key = itr.next();

            if(b.tree.get(key).coeff == 0){
                co0.add(key);

            }
        }
        for(int i = 0; i < co0.size();i++){
            b.tree.remove(co0.get(i));
        }
        return b;
    }

    /**
     * Generates a copy of a polynomial.
     * @param Polynomial whose copy is to be made.
     * @return Polynomial- a copy of the polynomial given as parameter.
     * <p>
     * This method iterates through a polynomial to generate a copy of it, so that when an operation is applied
     * on two polynomials, we use their copies rather than the actual ones. This keeps the polynomials given as 
     * inputs in their original state.
     */
    public Poly copy(Poly b){
        Set<Integer> set = b.tree.keySet();
        Iterator<Integer> itr = set.iterator();
        Poly co = new Poly();
        while(itr.hasNext()){
            int key = itr.next();
            Mono z = new Mono(b.tree.get(key).coeff, key);
            co.tree.put(key,z);
        }
        return co;
    }

    /**
     * Adds two polynomials
     * @param Polynomial - which is to be added to the polynomial on which 
     * the method is called
     * @return Polynomial-the sum of the two
     * <p>
     * This method first creates copies of the two polynomials on which the method is applied. It then checks 
     * which polynomial has more number of terms and iterates through it so none of the terms in the two 
     * polynomials are missed out. In a while loop, it is checked if both the polynomials have terms with the 
     * same exponent and if they do, we add their coefficents and add the new monomial to the copy of the
     * smaller polynomial. The new polynomial is returned after being checked for monomials with coeffcients 
     * zero by the checkForZero method.
     */
    public Poly add(Poly b){
        Poly d = new Poly();
        Poly c = new Poly();
        if(this.tree.size() >= b.tree.size()){
            d = copy(this);
            c = copy(b);
        }
        else{
            d = copy(b);
            c = copy(this);
        }
        Set<Integer> set = d.tree.keySet();
        Iterator<Integer> itr = set.iterator();

        while(itr.hasNext()){
            int key = itr.next();
            if(c.tree.containsKey(key)){
                Mono z = new Mono(d.tree.get(key).coeff + c.tree.get(key).coeff,d.tree.get(key).expo);
                c.tree.put(d.tree.get(key).expo, z);
                continue;
            }
            else{
                c.tree.put(key, d.tree.get(key));
                continue;
            }
        }
        return checkForZero(c);
    }

    /**
     * Subtracts two polynomials
     * @param Polynomial which is to be subtracted from the polynomial on which the 
     * method is called.
     * @return Polynomial-the difference of the two
     *  <p>
     *  This method first multiplies the coefficients of all the monomials in the polynomial which is to be 
     *  subtracted by -1. It then basically applies the same algorithm as in the add method.
     */
    public Poly subtract(Poly b){
        Poly neg1 = new Poly();
        neg1 = copy(b);
        Set<Integer> negset = neg1.tree.keySet();
        Iterator<Integer> neg = negset.iterator();
        while(neg.hasNext()){
            int key = neg.next();
            neg1.tree.get(key).coeff = neg1.tree.get(key).coeff*-1;
        }
        Poly d = new Poly();
        Poly c = new Poly();

        if(this.tree.size() >= b.tree.size()){
            d = copy(this);
            c = copy(neg1);
        }
        else{
            d = copy(neg1);
            c = copy(this);
        }

        Set<Integer> set = d.tree.keySet();
        Iterator<Integer> itr = set.iterator();

        while(itr.hasNext()){
            int key = itr.next();
            if(c.tree.containsKey(key)){
                Mono z = new Mono(d.tree.get(key).coeff + c.tree.get(key).coeff,d.tree.get(key).expo);
                c.tree.put(z.expo, z);
                continue;
            }
            else{
                c.tree.put(key, d.tree.get(key));
                continue;
            }
        }
        return checkForZero(c);
    }

    /**
     * Multiplies two polynomials.
     * @param Polynomial which is to be multiplied by the polynomial on which the 
     * method is called.
     * @return Polynomial - the product of the two polynomials
     * <p>
     * This method first creates copies of the two polynomials to be created. It then initialises two iterators
     * to iterate through both the polynomials. It then runs nested while loops to multiply each term of the 
     * first polynomial with each term of the second. The coefficients are multplied and the exponents added. 
     * There is an if statement to make sure that two terms with the same exponent are not added to the resultant
     * polynomial.
     */

    public Poly multiply(Poly b){
        Poly d = new Poly();
        Poly c = new Poly();

        d = copy(this);
        c = copy(b);

        Collection<Mono> set1 = d.tree.values();
        Iterator<Mono> itr1 = set1.iterator();
        Collection<Mono> set2 = c.tree.values();
        Iterator<Mono> itr2 = set2.iterator();

        Poly x = new Poly();

        while(itr1.hasNext()){
            Mono mo1 = itr1.next();

            while(itr2.hasNext()){

                Mono mo2 = itr2.next();

                int e = mo1.expo + mo2.expo;
                double co = mo1.coeff*mo2.coeff;
                if(x.tree.containsKey(e)){
                    co += x.tree.get(e).coeff;
                }

                Mono z = new Mono(co,e);

                x.tree.put(e,z);

            }
            itr2 = set2.iterator();
        }
        return x;
    }

    /**
     * Divides two polynomials.
     * @param Polynomial the divisor
     * @return Polynomial-the quotient of two completely divisible polynomials
     * <p>
     * The method first creates a copy of the dividend and sets an iterator through its keyset. It then creates
     * a copy of the divisor and saves its first key. This method makes use of a do-while loop. My method takes
     * monomials of the two one at a time and divides them(divide coeeficient & subtract exponents) and adds the  
     *  resultant monomial to the 'quo' polynomial whoch represents the quotient. This is then multiplied by the
     *  divisor (represented by 'quomul') and then subtracted from the dividend. The method throws an exception
     *  if something is divided by zero.
     */
    public Poly divide(Poly b) throws ArithmeticException{
        Poly a = this;
        Poly k = copy(a);
        Collection<Integer> set = k.tree.keySet();
        Iterator<Integer> itr = set.iterator();
        Poly l = copy(b);
        int check = l.tree.firstKey();
        Poly re = new Poly();
        int keynext;
        Poly rem = new Poly();
        do{
            try{
                keynext = itr.next();
            }
            catch(NoSuchElementException e){
                throw new ArithmeticException("Cannot divide by zero.");
            }
            Mono val1;  
            try{
                val1 = k.tree.get(k.tree.firstKey());
            }
            catch(NoSuchElementException e){
                break;
            }
            Mono val2 = l.tree.get(check);

            double co = val1.coeff/val2.coeff;
            int e;
             
            if(val1.expo >= val2.expo){
                e = val1.expo - val2.expo;
            }
            else{
                rem = k;
                break;
            }
            Mono temp = new Mono(co,e);
            Poly quo = new Poly(); 
            Poly quomul = new Poly();
            quo.tree.put(e,temp);
            re.tree.put(e,temp);
            quomul = quo.multiply(l);
            k = k.subtract(quomul);
            if(k.tree.isEmpty()){
                break;
            }

        }while(keynext >= check );

        return re;
    }

    /**
     * Implements the toString method for the Poly class.
     * @return A string representation of a polynomial.
     */
    public String toString(){
        Set<Integer> set = this.tree.keySet();
        Iterator<Integer> itr = set.iterator();
        String s = "";
        while(itr.hasNext()){
            int key = itr.next();
            if(key == this.tree.firstKey() || this.tree.get(key).coeff < 0){
                s += this.tree.get(key);
            }

            else{
                s += " + " + this.tree.get(key) ;
            }
        }
        return s;
    }
}
