
/**
 * A subclass of the Operator class, representing the subtract operator.
 *
 * @author Muhammad Furrukh Asif
 * @version CMPU-102
 */
public class SubOperator extends Operator
{
    // instance variables - replace the example below with your own
    private char a;
    private int priority;
    /**
     *  A constructor for the SubOperator class.
     *  <p>
     *  The character is initialised to be '-' and a priority of 1 is assigned.
     */
    public SubOperator()
    {
        priority = 1; 
        a = '-';
    }

    /**
     *  This method gives the priority of the subtract operator.
     * @return    Integer - the priority of the operator
     */
    public int getPriroity()
    {
        return priority;
    }
    /**
     * Implements the toString method for the SubOperator class.
     * @return String - a string representation of the operator.
     */
     public String toString(){
        String s;
        s = "" + '-';
        return s;
    }
}
