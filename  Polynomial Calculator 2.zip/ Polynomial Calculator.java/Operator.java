
/**
 *  This subclass of the Token class represents an operator.
 *
 * @author Muhammad Furrukh Asif
 * @version CMPU-102
 */
public class Operator extends Token
{
     
    private int priority;
    private char x;
    /**
     * A constructor for the class Operator.
     */
    public Operator()
    {
        this.x =x;
        this.priority = priority;
    }

    /**
     * This method gives the priority of an operator
     * @return    Integer - the priority of the operator based on the order of operations.
     */
    public int  getPriority()
    {
         
        return priority;
    }
    /**
     * Implements the toString method for the Operator class
     * @return String - string representation of the operator.
     */
     
    
    public String toString(){
        String s;
        s = "" + x;
        return s;
    }
}
