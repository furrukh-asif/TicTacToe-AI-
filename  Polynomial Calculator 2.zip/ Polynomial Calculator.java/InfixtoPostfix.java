
 
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.*;
import java.util.AbstractCollection;
import java.lang.Iterable;
/**
 * This class converts an arraylist of objects from infix to postfix notation. This is done because it is
 * easier for the computer to evaluate the postfix notation.
 * @author Muhammad Furrukh Asif
 * @version CMPU-102
 */
public class InfixtoPostfix{
    /**
     * This method takes in the arraylist given out by the FSM as input and converts it into postfix
     * notation.
     * @param An arraylist given out by the FSM
     * @return An arraylist of postfix notation
     * <p>
     * This method uses a for-loop to iterate through the arraylist of objects. If the object is a monomial, it
     * is added to the resultant arraylist. If it is an opening parenthesis, we create a new left parenthesis 
     * token an add it to the arraydeque of tokens. If it is a closing parenthesis, we run a while loop to empty
     * the arraydeque until we find an opening parenthesis. If at this stage the arraydeque is empty, it means
     * the parenthesis were mismatched and an exception is thrown. If not empty, we remove the right parenthesis 
     * from the deque. If the object in the input list is an operator, a new operator(Token class) of the type
     * is declared. Then a while loop is run in which the tokens from the deque are added to the resultant
     * list, while the deque is not empty, the next token is not a left parenthesis and the opeartor in the 
     * deque has a higher or equal priority to the one at hand in this iteration. And then the operator at hand
     * is added to the deque. Once this for loop ends, we run a while loop until the deque is empty, adding
     * the tokens to the resultant list. If a left parenthesis is found now it means the parenthesis are 
     * mismatched an exception is thrown. The resultant arraylist is then returned.
     */
    
    public ArrayList converter(ArrayList input) throws IllegalArgumentException {
         
        ArrayDeque<Token> lifo = new ArrayDeque<Token>();
        ArrayList result = new ArrayList();
        for(int i = 0; i < input.size();i++){    
            Object a = input.get(i);
            if(a instanceof Mono){
                 
                result.add(a);
            }
            else if(a.equals('(')){
                LeftParen z = new LeftParen();   
                lifo.addFirst(z); 
            }

            else if(a.equals(')')){
                 
                while(!lifo.isEmpty() && !(lifo.peek() instanceof LeftParen)){
                     Token d =   lifo.peek();
                     
                    
                     result.add(lifo.pop());
                    
                     
                     
                    
                }
                if(lifo.isEmpty()){
                    throw new IllegalArgumentException("Mismatched right parenthesis");
                     
                     
                }
                else
                lifo.pop();
            }

            else if(a.equals('+')||a.equals('-')||a.equals('*')||a.equals('/')){
                Operator op;
                if(a.equals('+'))
                op = new AddOperator();
                else if(a.equals('-'))
                op = new SubOperator();
                else if(a.equals('*'))
                op = new MulOperator();
                else
                op = new DivOperator();
                while(!lifo.isEmpty() && !(lifo.peek() instanceof LeftParen)
                &&  
                lifo.peek().getPriority() >= op.getPriority()){
                    result.add(lifo.pop());

                }
                lifo.push(op);
            }
             
             
        }
        while(!lifo.isEmpty()){
            Token z = lifo.pop();
            if(z instanceof LeftParen){
                
            throw new IllegalArgumentException("Mismatched left parenthesis");
             
        }
            else
                result.add(z);
        }
         
        return result;
    }
}